
# Proyecto de Chat en Tiempo Real con WebSocket

Este proyecto consiste en una aplicación de chat en tiempo real que utiliza WebSockets para permitir la comunicación bidireccional entre los usuarios conectados. Los mensajes se envían y reciben de manera instantánea sin necesidad de recargar la página, garantizando una experiencia interactiva y en tiempo real.

## Requisitos

Para ejecutar este proyecto en tu máquina, necesitas tener instalados los siguientes programas:

- [Node.js](https://nodejs.org/) (v14 o superior)
- [npm](https://www.npmjs.com/) (el gestor de paquetes de Node.js)

Además, este proyecto usa la librería `ws` para la implementación del WebSocket. Para instalarla, se utiliza npm.

## Instalación

Sigue estos pasos para configurar el proyecto en tu máquina:

1. Clona este repositorio en tu máquina local:

   ```bash
   git clone https://github.com/
   ```

2. Entra en el directorio del proyecto:

   ```bash
   cd chat-websocket
   ```

3. Instala las dependencias del proyecto:

   ```bash
   npm install
   ```

## Uso

Una vez que el proyecto esté instalado y configurado, puedes iniciar el servidor y la aplicación siguiendo estos pasos:

1. Inicia el servidor con el siguiente comando:

   ```bash
   node server.js
   ```

2. Abre tu navegador y ve a la siguiente URL para acceder a la aplicación de chat:

   ```
   http://localhost:8080
   ```

3. En la página del chat, los usuarios pueden conectarse automáticamente al WebSocket y comenzar a enviar y recibir mensajes en tiempo real.

## Funcionalidades

- Conexión de múltiples usuarios en tiempo real.
- Envío y recepción de mensajes instantáneos.
- Manejo de eventos de conexión y desconexión.
- Interfaz sencilla para una experiencia de usuario eficiente.

## Licencia

Este proyecto está bajo la Licencia MIT - consulta el archivo [LICENSE](LICENSE) para más detalles.

## Autor

[LuisMorales]
