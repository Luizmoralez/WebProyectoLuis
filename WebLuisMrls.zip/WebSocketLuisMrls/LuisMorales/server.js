const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

// Servidor HTTP
const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
  
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Archivo no encontrado');
    }
    res.writeHead(200);
    res.end(data);
  });
});

// Servidor WebSocket conectado al mismo servidor HTTP
const wss = new WebSocket.Server({ server });

wss.on('connection', socket => {
    console.log(`Clientes conectados: ${ wss.clients.size }`);

    // Manejar el mensaje recibido
    socket.on('message', msg => {
        const texto = msg.toString();  // Convierte el Buffer a texto
        console.log(texto);
        
        // Broadcast a todos los clientes
        wss.clients.forEach(client => {
            if (client !== socket && client.readyState === WebSocket.OPEN) {
                client.send(texto);
            }
        });
    });

    // Manejar desconexión de usuarios
    socket.on('close', () => {
        console.log('Un cliente se ha desconectado');
    });

    // Manejar errores en WebSocket
    socket.on('error', (error) => {
        console.error('Error en WebSocket:', error);
    });
});

server.listen(8080, () => {
  console.log('Servidor en http://localhost:8080');
});
